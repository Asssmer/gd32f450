#include "./454software/454software.h"

// SystemCoreClock

int main(void)
{
    uint8_t buff=0x55;
    init_454();
    int32_t XX = -200000000;
    while (1)
    {
        gpio_bit_toggle(GPIOG, GPIO_PIN_7);
        ms_delay_454(1000);
        log_454("start!!");
        // i2c_master_receive(I2C1, &buff, 1, 0xda);
        i2c_master_send(I2C1, &buff, 1, 0xda);
        usart1_send_454(&buff,sizeof(buff));

        // log_454(intToStr(XX));
    }
    return 0;
}
